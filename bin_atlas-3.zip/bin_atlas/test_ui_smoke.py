"""UI smoke test with a stub `flet` (no Flet install needed).
Clicks through every tab and action to catch NameErrors / wrong wiring.
It cannot check real Flet rendering - test the APK on a device for that."""
import os, sys, tempfile, types, unittest
from unittest import mock

HERE = os.path.dirname(os.path.abspath(__file__))
os.environ["FLET_APP_STORAGE_DATA"] = tempfile.mkdtemp()
EXPORT_DIR = os.path.join(tempfile.mkdtemp(), "BIN ATLAS")          # stands in for /storage/emulated/0/BIN ATLAS
os.environ["BINATLAS_EXPORT_DIRS"] = EXPORT_DIR
sys.path.insert(0, HERE)


class Ctl:
    def __init__(self, *a, **kw):
        self.args = a
        self.__dict__.update(kw)
        self.controls = list(a[0]) if a and isinstance(a[0], list) else list(kw.get("controls", []) or [])
        self.value = kw.get("value", None)


def make_ft():
    ft = mock.MagicMock()
    for name in ("Container", "Column", "Row", "Text", "TextField", "Switch", "Image", "ProgressBar",
                 "ProgressRing", "Icon", "IconButton", "TextButton", "SafeArea", "NavigationBar",
                 "NavigationBarDestination", "AlertDialog", "SnackBar", "FilePicker", "View"):
        setattr(ft, name, Ctl)
    return ft


def walk(c, seen=None):
    seen = seen if seen is not None else set()
    if id(c) in seen or not isinstance(c, Ctl):
        return
    seen.add(id(c))
    yield c
    for ch in list(c.controls) + list(c.args):
        if isinstance(ch, list):
            for x in ch:
                yield from walk(x, seen)
        else:
            yield from walk(ch, seen)
    for attr in ("content", "title", "actions", "options"):
        v = getattr(c, attr, None)
        if isinstance(v, list):
            for x in v:
                yield from walk(x, seen)
        elif isinstance(v, Ctl):
            yield from walk(v, seen)


class Page:
    def __init__(self):
        self.views = [Ctl()]                 # Flet's own (hidden) base view
        self.overlay, self.opened = [], []
        self.clipboard = ""
        self.on_view_pop = None

    def update(self): pass
    def open(self, c): self.opened.append(c)
    def close(self, c): pass
    def run_thread(self, fn, *a): fn(*a)
    def set_clipboard(self, t): self.clipboard = t


def texts(root):
    out = []
    for c in walk(root):
        if c.__class__ is Ctl and c.args and isinstance(c.args[0], str):
            out.append(c.value if isinstance(c.value, str) and c.value else c.args[0])
    return out


def click(root, label):
    for c in walk(root):
        if getattr(c, "on_click", None) and (c.args[:1] == (label,) or label in texts(c)):
            c.on_click(None)
            return True
    raise AssertionError(f"no clickable '{label}'")


def by_label(root, start):
    return next(c for c in walk(root) if c.__class__ is Ctl and str(getattr(c, "label", "")).startswith(start))


def goto(view, i):
    view.navigation_bar.on_change(types.SimpleNamespace(control=types.SimpleNamespace(selected_index=i)))


def wait_for(cond, timeout=2.0):
    import time
    end = time.time() + timeout
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.01)
    return False


BINLIST_OK = {"scheme": "visa", "type": "debit", "brand": "Visa Infinite", "prepaid": False,
              "number": {"luhn": True}, "country": {"name": "Italy", "alpha2": "IT", "alpha3": "ITA", "currency": "EUR"},
              "bank": {"name": "Revolut Bank UAB", "phone": "+1", "url": "x.com"}}
CSV = ("BIN,Brand,Type,Category,Issuer,IssuerPhone,IssuerUrl,isoCode2,isoCode3,CountryName\n"
       "011300,LOCAL BRAND,DEBIT,PROPRIETARY ATM,BDO UNIBANK INC,,,PH,PHL,PHILIPPINES\n"
       "011301,LOCAL BRAND,CREDIT,GOLD,METROBANK,,,PH,PHL,PHILIPPINES\n"
       "012004,VISA,CREDIT,GOLD,STATE BANK OF INDIA,,,IN,IND,INDIA\n")


def fake_net(url, headers=None, timeout=None, stream=False):
    if "raw.githubusercontent" in url:
        class R:
            status_code = 200
            def iter_content(self, n): yield CSV.encode()
        return R()
    if "binlist.io" in url:
        m = mock.Mock(status_code=200); m.json.return_value = BINLIST_OK; return m
    return mock.Mock(status_code=500)


class Smoke(unittest.TestCase):
    def start(self, ft):
        sys.modules.pop("main", None)
        import main as app
        page = Page()
        app.main(page)
        view = page.views[-1]
        self.assertIsNotNone(view.navigation_bar, "app failed to start: " + " ".join(texts(view)))
        return app, page, view

    def test_full_flow(self):
        ft = make_ft()
        with mock.patch.dict(sys.modules, {"flet": ft}), mock.patch("engine._http_get", fake_net), \
                mock.patch("engine.BinEngine.prewarm"):
            app, page, root = self.start(ft)
            self.assertEqual(len(page.views), 2)                                # hidden base view + app view

            # --- Lookup: no top note field; type 11 digits -> only 8 are used, no pop-up
            self.assertFalse(any(str(getattr(c, "label", "")).startswith("Note to save") for c in walk(root)))
            by_label(root, "BIN").value = "52792622911"
            click(root, "Look up")
            shown = " ".join(texts(root))
            self.assertIn("52792622", shown); self.assertIn("BIN 527926", shown); self.assertIn("REVOLUT BANK UAB", shown)
            self.assertNotIn("5279262291", shown)
            self.assertEqual(page.opened, [])
            for gone in ("Continent", "Dial code", "Prepaid", "Commercial", "Website", "Issuer phone"):
                self.assertNotIn(gone, shown)

            click(root, "Copy"); self.assertEqual(page.clipboard, "52792622")
            page.clipboard = ""
            next(c for c in walk(root) if getattr(c, "tooltip", "") == "Copy this number").on_click(None)
            self.assertEqual(page.clipboard, "52792622")

            by_label(root, "Note - saved").value = "client A"
            click(root, "Save")
            from engine import BinEngine
            self.assertEqual([(r["query"], r["bin"], r["note"]) for r in BinEngine().saved()],
                             [("52792622", "527926", "client A")])

            # --- Banks: download the offline database, then use the searchable pickers
            with mock.patch.object(app, "DEBOUNCE", 0):
                goto(root, 1)
                click(root, "Download BIN database")
                click(root, "Bank")
                self.assertTrue(any(s.startswith("Tip: choose a country first") for s in texts(page.opened[-1])))
                page.opened.pop()
                click(root, "Country")
                dlg = page.opened[-1]
                labels = texts(dlg)
                for want in ("All", "\U0001F1EE\U0001F1F3 India (IN)", "\U0001F1F5\U0001F1ED Philippines (PH)",
                             "\U0001F1EE\U0001F1F9 Italy (IT)", "\U0001F1FA\U0001F1F8 United States (US)"):
                    self.assertIn(want, labels)                                 # every country is offered
                search = by_label(dlg, "Type to search"); search.value = "phil"; search.on_change(None)
                self.assertEqual([x for x in texts(dlg) if "(" in x and ")" in x], ["\U0001F1F5\U0001F1ED Philippines (PH)"])
                click(dlg, "\U0001F1F5\U0001F1ED Philippines (PH)")

                click(root, "Bank")                                             # banks of the chosen country only
                dlg = page.opened[-1]
                self.assertIn("Showing only banks in \U0001F1F5\U0001F1ED Philippines (PH).", texts(dlg))
                self.assertTrue({"BDO UNIBANK INC", "METROBANK"} <= set(texts(dlg)))
                self.assertNotIn("STATE BANK OF INDIA", texts(dlg))
                search = by_label(dlg, "Type to search"); search.value = "bdo"; search.on_change(None)
                self.assertIn("BDO UNIBANK INC", texts(dlg)); self.assertNotIn("METROBANK", texts(dlg))
                click(dlg, "BDO UNIBANK INC")
                click(root, "Type"); dlg = page.opened[-1]
                self.assertIn("DEBIT", texts(dlg)); self.assertNotIn("CREDIT", texts(dlg))   # follows the chosen bank
                click(dlg, "DEBIT")

                click(root, "Search")
                t = " ".join(texts(root))
                self.assertIn("011300", t); self.assertNotIn("011301", t); self.assertIn("1 BIN(s) found", t)
                click(root, "Export TXT")
                self.assertIn("DATE : ", page.clipboard); self.assertIn("BDO UNIBANK INC", page.clipboard)
                saved_files = os.listdir(EXPORT_DIR)                            # written into the BIN ATLAS folder
                self.assertEqual(len(saved_files), 1); self.assertTrue(saved_files[0].startswith("bin_atlas_banks_"))
                self.assertTrue(any(EXPORT_DIR in s for s in texts(page.opened[-1])))
                with open(os.path.join(EXPORT_DIR, saved_files[0]), encoding="utf-8") as fh:
                    self.assertEqual(fh.read(), page.clipboard)

                click(root, "Country"); click(page.opened[-1], "\U0001F1EE\U0001F1F3 India (IN)")   # new country clears the rest
                click(root, "Search")
                self.assertIn("012004", " ".join(texts(root)))
                click(root, "Reset")
                click(root, "Search"); self.assertIn("BIN(s) found", " ".join(texts(root)))

            # --- Learn: multi-number Luhn
            goto(root, 2)
            self.assertIn("3 pass · 3 fail", " ".join(texts(root)))

            # --- Saved: tap opens details in place
            goto(root, 3)
            t = " ".join(texts(root))
            self.assertIn("52792622", t); self.assertIn("BIN 527926", t); self.assertIn("\u270E client A", t)
            next(c for c in walk(root) if c.__class__ is Ctl and getattr(c, "on_click", None)
                 and "\u270E client A" in texts(c)).on_click(None)
            self.assertIn("BIN details", " ".join(texts(root)))

            # --- Back button: from details -> back to Saved (no exit hint)
            shown_before = len(page.opened)
            page.on_view_pop(None)
            self.assertNotIn("BIN details", " ".join(texts(root)))
            self.assertIn("Saved (1)", " ".join(texts(root)))
            self.assertEqual(len(page.opened), shown_before)
            # --- on a main tab: first press hints, second press exits
            with mock.patch.object(app, "hard_exit") as hard:
                page.on_view_pop(None)
                self.assertIn("Press back again to exit", texts(page.opened[-1]))
                self.assertFalse(hard.called)
                page.on_view_pop(None)
                self.assertTrue(wait_for(lambda: hard.called))
                self.assertEqual(len(page.views), 1)                             # app view removed, base view left

            # --- Saved export
            click(root, "Export TXT")
            self.assertIn("52792622\n\U0001F517 TYPE \u279C VISA", page.clipboard)
            self.assertIn("\u2139\uFE0F NOTE \u279C client A", page.clipboard)
            self.assertNotIn("5279262291", page.clipboard)
            self.assertTrue(any(f.startswith("bin_atlas_saved_") for f in os.listdir(EXPORT_DIR)))

    def test_export_falls_back_with_clear_message(self):
        blocker = os.path.join(tempfile.mkdtemp(), "blocked")
        with open(blocker, "w") as fh: fh.write("x")
        ft = make_ft()
        with mock.patch.dict(os.environ, {"BINATLAS_EXPORT_DIRS": os.path.join(blocker, "BIN ATLAS")}), \
                mock.patch.dict(sys.modules, {"flet": ft}), mock.patch("engine.BinEngine.prewarm"):
            app, page, root = self.start(ft)
            goto(root, 1)
            click(root, "Search"); click(root, "Export TXT")
            msg = " ".join(texts(page.opened[-1]))
            self.assertIn("File: ", msg); self.assertIn("Storage", msg)         # tells the user how to unlock the folder
            self.assertIn("DATE : ", page.clipboard)

    def test_back_hint_expires(self):
        ft = make_ft()
        with mock.patch.dict(sys.modules, {"flet": ft}), mock.patch("engine.BinEngine.prewarm"):
            app, page, root = self.start(ft)
            with mock.patch.object(app, "hard_exit") as hard, mock.patch.object(app, "EXIT_WINDOW", 0.0):
                page.on_view_pop(None); page.on_view_pop(None)                  # window of 0 s: never a double press
                self.assertFalse(wait_for(lambda: hard.called, 0.5))

    def test_settings_dialog(self):
        ft = make_ft()
        with mock.patch.dict(sys.modules, {"flet": ft}), mock.patch("engine.BinEngine.prewarm"):
            app, page, root = self.start(ft)
            next(c for c in walk(root) if getattr(c, "tooltip", "") == "API keys & sources").on_click(None)
            dlg = page.opened[-1]
            handy = by_label(dlg, "HandyAPI")
            handy.value = "HAS-" + "q" * 20
            next(a for a in dlg.actions if a.args[0] == "Save & test").on_click(None)
            self.assertTrue(any("SECRET" in s for s in texts(dlg)))
            handy.value = "PUB-" + "q" * 20
            with mock.patch("engine._http_get", return_value=mock.Mock(status_code=401)):
                next(a for a in dlg.actions if a.args[0] == "Save & test").on_click(None)
            self.assertTrue(any("key rejected" in s for s in texts(dlg)))
            self.assertTrue(any("venelinkochev" in s for s in texts(dlg)))
            self.assertTrue(any(s.startswith("\u2713 TXT files are saved to:") and EXPORT_DIR in s for s in texts(dlg)))
            click(dlg, "Check storage")


if __name__ == "__main__":
    unittest.main()
