# BIN Atlas v1.3

BIN lookup, issuer search and Luhn practice. Flet 0.28.3 (Python), builds to Android.

## Tabs
- **Lookup** - one or many BINs (comma separated, 6 to 8 digits each); results appear as each is ready.
- **Banks** - bincheck.io-style filters Country > Brand > Bank > Type > Level. Each filter opens a searchable list
  that loads 40 rows at a time (no more freezing). Bank names only come from the chosen country. Paged results,
  Export TXT, and "Download BIN database" for every country offline.
- **Learn** - multi-number Luhn checker with step-by-step explanation (on-device, nothing stored).
- **Saved** - saved numbers (exactly as searched, up to 8 digits) with notes, save time, history, Export TXT.

## Back button
Back closes a picker, or leaves BIN details back to its tab. On a main tab, press back twice within 2 seconds to exit.

## TXT export folder
Files go to `/storage/emulated/0/BIN ATLAS`. Android 11+ only allows that after you switch on
"All files access" once: Settings > Apps > BIN ATLAS > Permissions > Files and media. Until then the app uses
`Documents/BIN ATLAS`, `Download/BIN ATLAS` or its private folder and says where (gear icon > Storage).

## Digits
At most the first 8 digits (the BIN/IIN) are sent, shown, saved or exported. Extra digits are dropped silently.

## Sources and keys
binlist.io -> HandyAPI -> binlist.net with automatic failover. Keys live only on the phone (gear icon).
Use the HandyAPI publishable key (PUB-...); the secret key (HAS-...) is refused.

## Run / test / build
    pip install flet==0.28.3 requests
    python main.py
    python -m unittest test_engine test_ui_smoke -v
    flet build apk --project "BIN Atlas" --org com.binatlas

## Credits
Offline BIN database: venelinkochev/bin-list-data (CC BY 4.0). Public BIN data may be incomplete or outdated.
